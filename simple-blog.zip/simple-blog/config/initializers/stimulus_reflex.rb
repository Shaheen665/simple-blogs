StimulusReflex.configure do |config|
  config.on_failed_sanity_checks = :warn
end